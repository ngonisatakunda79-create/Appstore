
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, query } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyBPdGAZT_U8xNBsU-S4NnC7WUQI8zM1LWI",
  authDomain: "vidfind-77a6a.firebaseapp.com",
  projectId: "vidfind-77a6a",
  storageBucket: "vidfind-77a6a.appspot.com",
  messagingSenderId: "813301438270",
  appId: "1:813301438270:web:2ebe4dec657167c5403e6f",
  measurementId: "G-N4NTHY2230"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth();
const db = getFirestore();
const storage = getStorage();

const signInBtn = document.getElementById("sign-in");
const profilePic = document.getElementById("profile-pic");
const usernameDisplay = document.getElementById("username");
const uploadSection = document.querySelector(".upload-section");
const uploadBtn = document.getElementById("upload-btn");
const videoFile = document.getElementById("video-file");
const videoTitle = document.getElementById("video-title");
const videoFeed = document.getElementById("video-feed");
const searchBtn = document.getElementById("search-btn");
const searchBox = document.getElementById("search-box");
const loader = document.getElementById("search-loader");
const thumbnailFile = document.getElementById("thumbnail-file");

let currentUser = null;

signInBtn.addEventListener("click", () => {
  const provider = new GoogleAuthProvider();
  signInWithPopup(auth, provider);
});

onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
    signInBtn.classList.add("hidden");
    uploadSection.classList.remove("hidden");
    profilePic.src = user.photoURL;
    profilePic.classList.remove("hidden");
    usernameDisplay.textContent = user.displayName;
    loadVideos();
  }
});

uploadBtn.addEventListener("click", async () => {
  const file = videoFile.files[0];
  const title = videoTitle.value;
  const thumb = thumbnailFile.files[0];
  if (!file || !title || !thumb || !currentUser) return alert("Fill all fields");

  const videoRef = ref(storage, \`videos/\${Date.now()}_\${file.name}\`);
  const thumbRef = ref(storage, \`thumbnails/\${Date.now()}_\${thumb.name}\`);

  await uploadBytes(videoRef, file);
  await uploadBytes(thumbRef, thumb);

  const videoURL = await getDownloadURL(videoRef);
  const thumbURL = await getDownloadURL(thumbRef);

  await addDoc(collection(db, "videos"), {
    title,
    url: videoURL,
    thumbnail: thumbURL,
    userId: currentUser.uid,
    username: currentUser.displayName,
    userPic: currentUser.photoURL,
    timestamp: Date.now()
  });

  videoFile.value = "";
  videoTitle.value = "";
  thumbnailFile.value = "";
  loadVideos();
});

async function loadVideos() {
  videoFeed.innerHTML = "";
  const q = query(collection(db, "videos"));
  const snapshot = await getDocs(q);

  snapshot.forEach(doc => {
    const data = doc.data();
    const div = document.createElement("div");
    div.className = "video-card";
    div.innerHTML = \`
      <img src="\${data.thumbnail}" class="video-thumb" />
      <video controls src="\${data.url}" class="video-half"></video>
      <div class="video-info">
        <h3>\${data.title}</h3>
        <div class="uploader">
          <img src="\${data.userPic}" class="avatar" />
          <span>\${data.username}</span>
        </div>
        <button class="like-btn">👍 Like</button>
        <button class="sub-btn">Subscribe</button>
        <a href="\${data.url}" download class="download-btn">⬇️</a>
      </div>
    \`;
    videoFeed.appendChild(div);
  });
}

searchBtn.addEventListener("click", async () => {
  const term = searchBox.value.trim().toLowerCase();
  if (!term) return;

  loader.classList.remove("hidden");
  videoFeed.innerHTML = "";
  const q = query(collection(db, "videos"));
  const snapshot = await getDocs(q);

  snapshot.forEach(doc => {
    const data = doc.data();
    if (data.title.toLowerCase().includes(term)) {
      const div = document.createElement("div");
      div.className = "video-card";
      div.innerHTML = \`
        <img src="\${data.thumbnail}" class="video-thumb" />
        <video controls src="\${data.url}" class="video-half"></video>
        <div class="video-info">
          <h3>\${data.title}</h3>
          <div class="uploader">
            <img src="\${data.userPic}" class="avatar" />
            <span>\${data.username}</span>
          </div>
          <button class="like-btn">👍 Like</button>
          <button class="sub-btn">Subscribe</button>
          <a href="\${data.url}" download class="download-btn">⬇️</a>
        </div>
      \`;
      videoFeed.appendChild(div);
    }
  });
  loader.classList.add("hidden");
});
